Recommended input: `annotations.jsonl`. Baseline and original are preserved under `baseline/`.

Read `code/docs/independent_review_handoff.md` and the interface definitions before implementing analyses. Full coverage: `coverage.jsonl`; surgical changes: `changes.jsonl`; open review notes: `unresolved.jsonl`; existing uncertainty annotations remain in `uncertainties.jsonl`. Adoption exclusions are explicit in `adoption.json` and `excluded-proposals.jsonl`. Use graph and review uncertainties at their recorded availability points. Human review is pending; start with `human-review/index.html`.
